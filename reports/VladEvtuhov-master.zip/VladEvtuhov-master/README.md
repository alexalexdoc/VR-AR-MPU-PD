# Индивидуальный план работы Евтухова В.Д.
1) Просмотреть курс по Maya  "Pluralsight - Maya Modeling Fundamentals"


